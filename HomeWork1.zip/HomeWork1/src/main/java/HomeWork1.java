public class HomeWork1 {
    public static void main(String[] args){
       //float result= calSum(30f,15f,40f,10f);
       // System.out.println(result);
       //boolean result=numSUM(5,9);
        //System.out.println( result);
        //PositiveOrNegative(5);
        greetings("Даниил");
    }
    /*public static float calSum(float a, float b, float c, float d){
        return  a * (b + (c / d));
    }
    */
      /*public static boolean numSUM(int a, int b){
        int c=a+b;
        boolean result= c>=10 && c<=20;
        return result;
    }
       public static void PositiveOrNegative (int a){
          if(a>=0){
            System.out.println("положительное");
        } else {
            System.out.println("отрицательное");
        }
    }
       */
    public static void greetings(String name){
        System.out.println("Привет"+ name);
    }
}
